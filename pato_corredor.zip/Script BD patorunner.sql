CREATE DATABASE patorunner;
USE patorunner;
DROP DATABASE patorunner;
SELECT * FROM pato;
DROP TABLE pato;
DELETE FROM pato;

CREATE TABLE pato (
    id_pato INT AUTO_INCREMENT PRIMARY KEY,
    nick_name VARCHAR(255) NOT NULL,
    idade_pato INT NOT NULL,
    sexo ENUM("Macho", "Fêmea") NOT NULL,	
    categoria_corrida ENUM("5 Metros", "10 Metros", "15 metros") NOT NULL,
    resultado_corrida ENUM("1º", "2º", "3º", "4º", "5º") NOT NULL
);

INSERT INTO pato (id_pato, nick_name, idade_pato, sexo, categoria_corrida, resultado_corrida) VALUE
	("1","Patinhas","2","Macho","5 Metros","3º"),
	("2","Patolino","3","Macho","10 Metros","2º"),
	("3","Donald","1","Macho","15 metros","4º"),
    ("4","Margarida","1","Fêmea","5 Metros","5º");