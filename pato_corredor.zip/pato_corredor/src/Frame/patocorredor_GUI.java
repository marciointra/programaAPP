
package Frame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class patocorredor_GUI extends javax.swing.JFrame {

    public patocorredor_GUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jsclp_fundo = new javax.swing.JScrollPane();
        jtbl_mostrar = new javax.swing.JTable();
        jbtn_adicionar = new javax.swing.JButton();
        jbtn_editar = new javax.swing.JButton();
        jbtn_pesquisar = new javax.swing.JButton();
        jbtn_apagar = new javax.swing.JButton();
        jlbl_titulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(900, 250));
        setMinimumSize(new java.awt.Dimension(800, 600));
        setPreferredSize(new java.awt.Dimension(800, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jtbl_mostrar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nick", "Idade", "Sexo", "Categoria", "Resultado"
            }
        ));
        jsclp_fundo.setViewportView(jtbl_mostrar);

        getContentPane().add(jsclp_fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 109, 800, 480));

        jbtn_adicionar.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        jbtn_adicionar.setText("Adicionar");
        jbtn_adicionar.setMargin(new java.awt.Insets(5, 20, 5, 20));
        jbtn_adicionar.setPreferredSize(new java.awt.Dimension(130, 35));
        jbtn_adicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_adicionarActionPerformed(evt);
            }
        });
        getContentPane().add(jbtn_adicionar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, -1, -1));

        jbtn_editar.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        jbtn_editar.setText("Editar");
        jbtn_editar.setMargin(new java.awt.Insets(5, 20, 5, 20));
        jbtn_editar.setPreferredSize(new java.awt.Dimension(130, 35));
        jbtn_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_editarActionPerformed(evt);
            }
        });
        getContentPane().add(jbtn_editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, -1, -1));

        jbtn_pesquisar.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        jbtn_pesquisar.setText("Pesquisar");
        jbtn_pesquisar.setMargin(new java.awt.Insets(5, 20, 5, 20));
        jbtn_pesquisar.setPreferredSize(new java.awt.Dimension(130, 35));
        jbtn_pesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_pesquisarActionPerformed(evt);
            }
        });
        getContentPane().add(jbtn_pesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, -1, -1));

        jbtn_apagar.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        jbtn_apagar.setText("Apagar");
        jbtn_apagar.setMargin(new java.awt.Insets(5, 20, 5, 20));
        jbtn_apagar.setPreferredSize(new java.awt.Dimension(130, 35));
        jbtn_apagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_apagarActionPerformed(evt);
            }
        });
        getContentPane().add(jbtn_apagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 60, -1, -1));

        jlbl_titulo.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jlbl_titulo.setText("DUCK RUNNER v1.0");
        getContentPane().add(jlbl_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, -1, -1));
        jlbl_titulo.getAccessibleContext().setAccessibleName("jlbl_titulo");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtn_adicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_adicionarActionPerformed
     /*******************************************************************************************************************************************/
    //METODO PARA CADASTRAR USANDO O "INSERT INTO" VULGO "INSERIR INFORMAÇÃO NO BANCO"
     try {
            Connection conexao = null;
            PreparedStatement statement = null;
            
            String url = "jdbc:mysql://localhost:3306/patorunner";
            String usuario = "root";
            String senha = "";
            
            conexao = DriverManager.getConnection(url, usuario, senha);
            
            String sql = "INSERT INTO pato (nick_name, idade_pato, sexo, categoria_corrida, resultado_corrida) VALUES (?, ?, ?, ?, ?)";
            
            statement = conexao.prepareStatement(sql);
            
            // Exemplo dos valores que podem ser coletados de JTextFields
            String nickName = JOptionPane.showInputDialog("Nick Name:");
            String idadeStr = JOptionPane.showInputDialog("Idade:");
            String sexo = JOptionPane.showInputDialog("Sexo (Macho/Fêmea):");
            String categoriaCorrida = JOptionPane.showInputDialog("Categoria Corrida (5 Metros/10 Metros/15 Metros):");
            String resultadoCorrida = JOptionPane.showInputDialog("Resultado Corrida (1º/2º/3º/4º/5º):");

            statement.setString(1, nickName);
            statement.setInt(2, Integer.parseInt(idadeStr));
            statement.setString(3, sexo);
            statement.setString(4, categoriaCorrida);
            statement.setString(5, resultadoCorrida);
            
            statement.executeUpdate();
            
            // Adicionando os dados diretamente na JTable
            DefaultTableModel model = (DefaultTableModel) jtbl_mostrar.getModel();
            model.addRow(new Object[]{null, nickName, Integer.parseInt(idadeStr), sexo, categoriaCorrida, resultadoCorrida});
            
            JOptionPane.showMessageDialog(null, "Dados salvos com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar!");
            System.out.println(ex.getMessage());
        }

    }//GEN-LAST:event_jbtn_adicionarActionPerformed
     /*******************************************************************************************************************************************/
    private void jbtn_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_editarActionPerformed
     //METODO PARA EDITAR USANDO O "UPDATE" VULGO "ATUALIZAR INFORMAÇÃO NO BANCO"
    String idStr = JOptionPane.showInputDialog("ID do registro para atualizar:");
    if (idStr != null) {
        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID deve ser um número.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nickName = JOptionPane.showInputDialog("Novo Nick Name:");
        String idadeStr = JOptionPane.showInputDialog("Nova Idade:");
        String sexo = JOptionPane.showInputDialog("Novo Sexo (Macho/Fêmea):");
        String categoriaCorrida = JOptionPane.showInputDialog("Nova Categoria Corrida (5 Metros/10 Metros/15 Metros):");
        String resultadoCorrida = JOptionPane.showInputDialog("Novo Resultado Corrida (1ª/2ª/3ª/4ª/5ª):");

        if (nickName != null && idadeStr != null && sexo != null && categoriaCorrida != null && resultadoCorrida != null) {
            int idade;
            try {
                idade = Integer.parseInt(idadeStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Idade deve ser um número.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "UPDATE pato SET nick_name = ?, idade_pato = ?, sexo = ?, categoria_corrida = ?, resultado_corrida = ? WHERE id_pato = ?";
            try {
                Connection conexao = null;
                PreparedStatement statement = null;

                String url = "jdbc:mysql://localhost:3306/patorunner";
                String usuario = "root";
                String senha = "";

                conexao = DriverManager.getConnection(url, usuario, senha);
                statement = conexao.prepareStatement(sql);

                statement.setString(1, nickName);
                statement.setInt(2, idade);
                statement.setString(3, sexo);
                statement.setString(4, categoriaCorrida);
                statement.setString(5, resultadoCorrida);
                statement.setInt(6, id);

                statement.executeUpdate();
                JOptionPane.showMessageDialog(this, "Registro atualizado com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                
                // Atualizar a tabela
                jbtn_pesquisarActionPerformed(evt);

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Erro ao atualizar o registro.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    }//GEN-LAST:event_jbtn_editarActionPerformed
     /*******************************************************************************************************************************************/
    private void jbtn_pesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_pesquisarActionPerformed
     // METODO PARA PESQUISAR USANDO O "SELECT" VULGO "PESQUISAR INFORMAÇÃO NO BANCO"
    String sql = "SELECT * FROM pato";
    try {
        Connection conexao = null;
        Statement stmt = null;
        ResultSet rs = null;

        String url = "jdbc:mysql://localhost:3306/patorunner";
        String usuario = "root";
        String senha = "";

        conexao = DriverManager.getConnection(url, usuario, senha);
        stmt = conexao.createStatement();
        rs = stmt.executeQuery(sql);

        DefaultTableModel model = (DefaultTableModel) jtbl_mostrar.getModel();
        model.setRowCount(0); // Limpar a tabela antes de adicionar os novos dados

        while (rs.next()) {
            int id = rs.getInt("id_pato");
            String nickName = rs.getString("nick_name");
            int idade = rs.getInt("idade_pato");
            String sexo = rs.getString("sexo");
            String categoriaCorrida = rs.getString("categoria_corrida");
            String resultadoCorrida = rs.getString("resultado_corrida");

            model.addRow(new Object[]{id, nickName, idade, sexo, categoriaCorrida, resultadoCorrida});
        }

        JOptionPane.showMessageDialog(this, "Registros carregados com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Erro ao carregar os registros.", "Erro", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_jbtn_pesquisarActionPerformed

    private void jbtn_apagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_apagarActionPerformed
    // METODO PARA PESQUISAR USANDO O "SELECT" VULGO "PESQUISAR INFORMAÇÃO NO BANCO"
        String idStr = JOptionPane.showInputDialog("ID do registro para deletar:");
        if (idStr != null) {
            int id;
            try {
                id = Integer.parseInt(idStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID deve ser um número.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "DELETE FROM pato WHERE id_pato = ?";
            try {
                Connection conexao = null;
                PreparedStatement statement = null;

                String url = "jdbc:mysql://localhost:3306/patorunner";
                String usuario = "root";
                String senha = "";

                conexao = DriverManager.getConnection(url, usuario, senha);
                statement = conexao.prepareStatement(sql);

                statement.setInt(1, id);
                int rowsAffected = statement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Registro deletado com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Registro não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                }

                // Atualizar a tabela
                jbtn_pesquisarActionPerformed(evt);

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Erro ao deletar o registro.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_jbtn_apagarActionPerformed

    /*#########################################################################################*/
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(patocorredor_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(patocorredor_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(patocorredor_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(patocorredor_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new patocorredor_GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jbtn_adicionar;
    private javax.swing.JButton jbtn_apagar;
    private javax.swing.JButton jbtn_editar;
    private javax.swing.JButton jbtn_pesquisar;
    private javax.swing.JLabel jlbl_titulo;
    private javax.swing.JScrollPane jsclp_fundo;
    private javax.swing.JTable jtbl_mostrar;
    // End of variables declaration//GEN-END:variables

    private void DefaultTableModel() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
