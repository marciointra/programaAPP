-- Renomeando table "tela" para "aluno"
RENAME TABLE tela TO aluno;

-- Alterando na table "aluno" mudar nome da column "id_tabela" para "id_nome" e o tipo "INT"
ALTER TABLE aluno CHANGE COLUMN id_tabela id_nome INT;

-- Criando database chamada "senai"
CREATE DATABASE senai;

-- Excluindo database chamada "senai"
DROP DATABASE senai;

-- usando database chamada "senai"
USE senai;

-- Criando table chamada "aluno" com as columns
CREATE TABLE aluno(
	id_nome INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(40) NOT NULL,
    sobrenome VARCHAR(50) NOT NULL,
    cpf CHAR(11) NOT NULL
);

-- Mostrando toda tabela "aluno"
select * from aluno;
