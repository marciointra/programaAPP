
package com.mycompany.projeto_17_marcio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class home_page extends javax.swing.JFrame {

    public home_page() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jpl_fundo = new javax.swing.JPanel();
        jlb_id = new javax.swing.JLabel();
        jtxf_id = new javax.swing.JTextField();
        jlb_nome = new javax.swing.JLabel();
        jtxf_nome = new javax.swing.JTextField();
        jlb_sobrenome = new javax.swing.JLabel();
        jtxf_sobrenome = new javax.swing.JTextField();
        jlb_cpf = new javax.swing.JLabel();
        jtxf_cpf = new javax.swing.JTextField();
        jlb_pesquisa = new javax.swing.JLabel();
        jtxf_pesquisa = new javax.swing.JTextField();
        jlb_resutado = new javax.swing.JLabel();
        jtxf_resultado = new javax.swing.JTextField();
        jbt_cadastrar = new javax.swing.JButton();
        jbt_atualizar = new javax.swing.JButton();
        jbt_deletar = new javax.swing.JButton();
        jbt_pesquisa = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpl_fundo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlb_id.setText("ID");
        jpl_fundo.add(jlb_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, -1, -1));

        jtxf_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxf_idActionPerformed(evt);
            }
        });
        jpl_fundo.add(jtxf_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, 144, -1));

        jlb_nome.setText("Nome");
        jpl_fundo.add(jlb_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, -1, -1));
        jpl_fundo.add(jtxf_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, 144, -1));

        jlb_sobrenome.setText("Sosbre nome");
        jpl_fundo.add(jlb_sobrenome, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, -1, -1));
        jpl_fundo.add(jtxf_sobrenome, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, 144, -1));

        jlb_cpf.setText("CPF");
        jpl_fundo.add(jlb_cpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, -1, -1));
        jpl_fundo.add(jtxf_cpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 144, -1));

        jlb_pesquisa.setText("Pesquisar ID");
        jpl_fundo.add(jlb_pesquisa, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, -1, -1));

        jtxf_pesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxf_pesquisaActionPerformed(evt);
            }
        });
        jpl_fundo.add(jtxf_pesquisa, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 270, 144, -1));

        jlb_resutado.setText("Resultado");
        jpl_fundo.add(jlb_resutado, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, -1, -1));

        jtxf_resultado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxf_resultadoActionPerformed(evt);
            }
        });
        jpl_fundo.add(jtxf_resultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 310, 144, -1));

        jbt_cadastrar.setText("Cadastrar");
        jbt_cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_cadastrarActionPerformed(evt);
            }
        });
        jpl_fundo.add(jbt_cadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 410, -1, -1));

        jbt_atualizar.setText("Atualizar");
        jbt_atualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_atualizarActionPerformed(evt);
            }
        });
        jpl_fundo.add(jbt_atualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 410, -1, -1));

        jbt_deletar.setText("Deletar");
        jbt_deletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_deletarActionPerformed(evt);
            }
        });
        jpl_fundo.add(jbt_deletar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, -1, -1));

        jbt_pesquisa.setText("Pesquisar");
        jbt_pesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_pesquisaActionPerformed(evt);
            }
        });
        jpl_fundo.add(jbt_pesquisa, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 410, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jpl_fundo, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jpl_fundo, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /*******************************************************************************************************************************************/
    //METODO PARA CADASTRAR USANDO O "INSERT INTO" VULGO "INSERIR INFORMAÇÃO NO BANCO"
    private void jbt_cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_cadastrarActionPerformed
        try {
            Connection conexao = null;
            PreparedStatement statement = null;
            
            String url = "jdbc:mysql://localhost:3306/senai";
            String usuario = "root";
            String senha = "";
            
            conexao = DriverManager.getConnection (url, usuario, senha) ;
            String sql = "INSERT INTO aluno(id_nome, nome, sobrenome, cpf) VALUES (?, ?, ?, ?)";
            
            statement = conexao.prepareStatement(sql);
            statement.setString(1, jtxf_id.getText());
            statement.setString(2, jtxf_nome.getText());
            statement.setString(3, jtxf_sobrenome.getText());
            statement.setString(4, jtxf_cpf.getText());
            statement.executeUpdate();
            
            System.out.println("Aluno cadastrado com sucesso!");
            
            // TODO add your handling code here:
        } catch (SQLException ex) {
           System.out.println("Erro ao cadastrar novo aluno!");
          System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_jbt_cadastrarActionPerformed

    private void jtxf_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxf_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxf_idActionPerformed

    private void jtxf_pesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxf_pesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxf_pesquisaActionPerformed
    /*******************************************************************************************************************************************/
    //METODO PARA ATUALIZAR USANDO O "UPDATE" VULGO "EDITAR INFORMAÇÃO NO BANCO"
    private void jbt_atualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_atualizarActionPerformed
        try {
            Connection conexao = null;
            PreparedStatement statement = null;
            
            String url = "jdbc:mysql://localhost:3306/senai";
            String usuario = "root";
            String senha = "";
            
            conexao = DriverManager.getConnection (url, usuario, senha) ;
            String sql = "UPDATE aluno SET nome = ?, sobrenome = ?, cpf = ?  where id_nome = ?";
            
            statement = conexao.prepareStatement(sql);
            statement.setString(1, jtxf_nome.getText());
            statement.setString(2, jtxf_sobrenome.getText());
            statement.setString(3, jtxf_cpf.getText());
            statement.setString(4, jtxf_id.getText());
            statement.executeUpdate();
            
            System.out.println("Alteração de cadastro aluno feito com sucesso!");
            
        } catch (SQLException ex) {
          System.out.println("Erro ao editar cadastro aluno!");
          System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_jbt_atualizarActionPerformed
    /*******************************************************************************************************************************************/
    //METODO PARA DELETAR USANDO O "DELETE" VULGO "APAGAR INFORMAÇÃO NO BANCO"
    private void jbt_deletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_deletarActionPerformed

        try {
            Connection conexao = null;
            PreparedStatement statement = null;
            
            String url = "jdbc:mysql://localhost:3306/senai";
            String usuario = "root";
            String senha = "";
            
            conexao = DriverManager.getConnection (url, usuario, senha) ;
            String sql = "DELETE FROM aluno WHERE id_nome = ?";
            
            statement = conexao.prepareStatement(sql);
            statement.setString(1, jtxf_id.getText());

            statement.executeUpdate();
            
            System.out.println("Excluindo com sucesso!");
            
            
        } catch (SQLException ex) {
          System.out.println("Erro ao excluir cadastro do aluno!");
          System.out.println(ex.getMessage()); 
        }
    }//GEN-LAST:event_jbt_deletarActionPerformed
    /*******************************************************************************************************************************************/
    //METODO PARA PESQUISAR USANDO O "READ" VULGO "BUSCAR INFORMAÇÃO NO BANCO"
    private void jbt_pesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_pesquisaActionPerformed

        try {
            Connection conexao = null;
            PreparedStatement statement = null;
            
            String url = "jdbc:mysql://localhost:3306/senai";
            String usuario = "root";
            String senha = "";
            
            conexao = DriverManager.getConnection (url, usuario, senha) ;
            String sql = "SELECT nome FROM aluno WHERE id_nome = ?";
            
            statement = conexao.prepareStatement(sql);
            statement.setString(1, jtxf_id.getText());

            ResultSet resultSet =  statement.executeQuery();
            if (resultSet.next()){
                try {
                    String nome = resultSet.getString("nome");
                    jtxf_resultado.setText(nome);
                } catch (SQLException ex) {
                    Logger.getLogger(conect.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{
                jtxf_resultado.setText("Aluno não encontrado");
            }

        } catch (SQLException ex) {
          System.out.println("Erro ao localizar cadastro do aluno!");
          System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_jbt_pesquisaActionPerformed

    private void jtxf_resultadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxf_resultadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxf_resultadoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new home_page().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jbt_atualizar;
    private javax.swing.JButton jbt_cadastrar;
    private javax.swing.JButton jbt_deletar;
    private javax.swing.JButton jbt_pesquisa;
    private javax.swing.JLabel jlb_cpf;
    private javax.swing.JLabel jlb_id;
    private javax.swing.JLabel jlb_nome;
    private javax.swing.JLabel jlb_pesquisa;
    private javax.swing.JLabel jlb_resutado;
    private javax.swing.JLabel jlb_sobrenome;
    private javax.swing.JPanel jpl_fundo;
    private javax.swing.JTextField jtxf_cpf;
    private javax.swing.JTextField jtxf_id;
    private javax.swing.JTextField jtxf_nome;
    private javax.swing.JTextField jtxf_pesquisa;
    private javax.swing.JTextField jtxf_resultado;
    private javax.swing.JTextField jtxf_sobrenome;
    // End of variables declaration//GEN-END:variables
}
