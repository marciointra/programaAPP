/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_17_marcio;

/**
 *
 * @author p.rosa
 */
public class projeto_17_marcio {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
